# 应用启动页广告显示，导航栏按钮动态变化
#详见效果图
//效果图
![](https://github.com/HaoRuizhi/WelecomePageAD/blob/master/启动页广告按钮动画.gif)

