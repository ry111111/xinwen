//
//  RootViewController.h
//  ADWelecomePage
//
//  Created by haorise on 15-12-3.
//  Copyright (c) 2015年 rise's company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
