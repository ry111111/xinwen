//
//  PM2d5Model.m
//  ADWelecomePage
//
//  Created by haorise on 15-12-8.
//  Copyright (c) 2015年 rise's company. All rights reserved.
//

#import "PM2d5Model.h"

@implementation PM2d5Model


@end
