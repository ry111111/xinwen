//
//  WeatherDetailModel.h
//  ADWelecomePage
//
//  Created by haorise on 15-12-8.
//  Copyright (c) 2015年 rise's company. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeatherDetailModel : NSObject

@property (nonatomic, copy) NSString *wind;
@property (nonatomic, copy) NSString *nongli;
@property (nonatomic, copy) NSString *date;
@property (nonatomic, copy) NSString *climate;
@property (nonatomic, copy) NSString *temperature;
@property (nonatomic, copy) NSString *week;

@end
