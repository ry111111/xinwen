//
//  SXHTTPManager.h
//  ADWelecomePage
//
//  Created by haorise on 15-12-3.
//  Copyright (c) 2015年 rise's company. All rights reserved.
//


#import "AFHTTPRequestOperationManager.h"

@interface SXHTTPManager : AFHTTPRequestOperationManager

+ (instancetype)manager;

@end
